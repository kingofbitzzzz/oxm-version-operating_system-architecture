package runtime;

import filesystem.filesystem;
import syntax.syntax;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.BorderFactory;
import javax.swing.border.Border;

public class runtime {
	private final Map<String, Double> values = new LinkedHashMap<String, Double>();
	private final Map<String, ScreenObject> objects = new LinkedHashMap<String, ScreenObject>();
	private final Map<String, ScreenObject> memory = new HashMap<String, ScreenObject>();
	private final Map<String, Color> styleColors = new HashMap<String, Color>();
	private final List<MessagePattern> blockedMessages = new ArrayList<MessagePattern>();
	private final List<RepeatRule> repeatRules = new ArrayList<RepeatRule>();
	private List<String> activeScriptLines = new ArrayList<String>();
	private Map<String, Integer> sectionLines = new HashMap<String, Integer>();
	private final Properties persistedMemory = new Properties();
	private final Path memoryPath = Paths.get(System.getenv("LOCALAPPDATA") == null
			? System.getProperty("user.home") : System.getenv("LOCALAPPDATA"), "Oxm", "memory.properties");
	private String programName = "Oxm screen";
	private JFrame frame;
	private JPanel canvas;
	private boolean skipNextLine;
	private boolean mockEnabled;
	private String requestedSection;

	public static void main(String[] args) throws Exception {
		runtime interpreter = new runtime();
		interpreter.installLauncher();
		if (args.length > 0) {
			interpreter.run(Paths.get(args[0]));
		} else {
			interpreter.shell();
		}
	}

	private runtime() {
		if (Files.isRegularFile(memoryPath)) {
			try (InputStream input = Files.newInputStream(memoryPath)) {
				persistedMemory.load(input);
			} catch (IOException exception) {
				System.err.println("Could not read Oxm memory: " + exception.getMessage());
			}
		}
	}

	private void shell() throws IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
		System.out.println("Oxm shell. Enter Oxm statements, run <file.oxm>, or exit.");
		while (true) {
			System.out.print("oxm> ");
			String line = input.readLine();
			if (line == null || line.trim().equalsIgnoreCase("exit")) {
				return;
			}
			if (line.trim().toLowerCase().startsWith("run ")) {
				run(Paths.get(line.trim().substring(4).trim().replaceAll("^\"|\"$", "")));
			} else if (line.trim().equalsIgnoreCase("help")) {
				System.out.println(syntax.help());
			} else {
				execute(line);
				if (requestedSection != null) {
					String section = requestedSection;
					requestedSection = null;
					runSection(section);
				}
			}
		}
	}

	private void run(Path file) throws IOException {
		List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
		activeScriptLines = lines;
		sectionLines = findSections(lines);
		Set<Integer> skipped = skippedLines(lines);
		skipNextLine = false;
		for (int index = 0; index < lines.size();) {
			if (skipped.contains(index + 1)) {
				index++;
				continue;
			}
			if (skipNextLine) {
				skipNextLine = false;
				index++;
				continue;
			}
			execute(lines.get(index));
			if (requestedSection != null) {
				Integer target = sectionLines.get(requestedSection.toLowerCase());
				if (target == null) {
					System.err.println("No section named /" + requestedSection + ".");
					requestedSection = null;
					index++;
				} else {
					index = target.intValue();
					requestedSection = null;
				}
			} else {
				index++;
			}
		}
	}

	private void execute(String source) {
		String line = stripDescription(source).trim();
		if (line.isEmpty() || line.startsWith("/") || line.startsWith("#")) {
			return;
		}
		Matcher mock = Pattern.compile("(?i)^teletypewriter\\.mock\\s+(on|off)$").matcher(line);
		Matcher typed = Pattern.compile("(?i)^teletypewriter\\.type\\s+\"([^\"]*)\"$").matcher(line);
		Matcher command = Pattern.compile("(?i)^teletypewriter\\.cmd\\s+\"([^\"]*)\"$").matcher(line);
		Matcher block = Pattern.compile("(?i)^teletypewriter\\.block\\s+\"([^\"]+)\"$").matcher(line);
		Matcher repeat = Pattern.compile("(?i)^teletypewriter\\.if(\\d+)ti\\s+\"([^\"]+)\"\\s+run\\s+([\\w-]+)$").matcher(line);
		if (mock.matches()) {
			mockEnabled = mock.group(1).equalsIgnoreCase("on");
		} else if (typed.matches()) {
			processMessage(typed.group(1), true);
		} else if (command.matches()) {
			runCommand(command.group(1));
		} else if (block.matches()) {
			MessagePattern messagePattern = MessagePattern.parse(block.group(1));
			if (messagePattern == null) {
				System.err.println("Block format must be \"&start;&end\": " + block.group(1));
			} else {
				blockedMessages.add(messagePattern);
			}
		} else if (repeat.matches()) {
			int count = Integer.parseInt(repeat.group(1));
			MessagePattern messagePattern = MessagePattern.parse(repeat.group(2));
			if (count < 1 || messagePattern == null) {
				System.err.println("Invalid teletypewriter repeat rule: " + line);
			} else {
				repeatRules.add(new RepeatRule(count, messagePattern, repeat.group(3)));
			}
		} else if (line.matches("(?i)^root:.*")) {
			if (!line.toLowerCase().contains(".oxm")) {
				System.err.println("Root filenames should end in .oxm");
			}
		} else if (line.matches("(?i)^int\\s*=.*")) {
			assign(line);
		} else if (line.matches("(?i)^colour-[\\w-]+\\s*=.*")) {
			setStyleColor(line);
		} else if (line.matches("(?i)^[-+]?\\w+\\s*[+-]\\s*[-+]?\\w+.*")) {
			if (!math(line)) {
				processMessage(source, mockEnabled);
			}
		} else if (line.matches("(?i)^back conditions;skip=.*")) {
		} else if (line.matches("(?i)^group\\s+.*")) {
			Matcher group = Pattern.compile("(?i)^group\\s+\\w+\\s*,\\s*\\w+\\s+\"([^\"]+)\"").matcher(line);
			if (group.matches()) {
				programName = group.group(1);
			}
		} else if (line.matches("(?i)^edit\\s+\"[^\"]+\"$")) {
			Matcher edit = Pattern.compile("(?i)^edit\\s+\"([^\"]+)\"$").matcher(line);
			if (edit.matches()) {
				programName = edit.group(1);
				showScreen();
			}
		} else if (line.matches("(?i)^screen_load(?:\\s+.*)?$")) {
			showScreen();
		} else if (line.matches("(?i)^add\\s+_.*")) {
			addObject(line);
		} else if (line.matches("(?i)^delete\\s+.*")) {
			deleteObject(line);
		} else if (line.matches("(?i)^memory\\s+(add|load)\\s+.*")) {
			memoryCommand(line);
		} else if (line.matches("(?i)^x,y;.*")) {
			setCoordinates(line);
		} else if (line.matches("(?i)^fetch\\s*;.*")) {
			System.out.println("fetch: not configured");
		} else if (line.matches("(?i)^out:.*")) {
			System.out.println(line.substring(line.indexOf(':') + 1));
		} else if (line.matches("(?i)^time\\s+_\\d+s$")) {
			System.out.println(line);
		} else {
			processMessage(source, mockEnabled);
		}
	}

	private void processMessage(String message, boolean echo) {
		for (MessagePattern pattern : blockedMessages) {
			if (pattern.matches(message)) {
				return;
			}
		}
		if (echo) {
			System.out.println(message);
		}
		for (RepeatRule rule : repeatRules) {
			if (!rule.pattern.matches(message)) {
				rule.lastMessage = null;
				rule.count = 0;
				rule.fired = false;
				continue;
			}
			if (message.equals(rule.lastMessage)) {
				rule.count++;
			} else {
				rule.lastMessage = message;
				rule.count = 1;
				rule.fired = false;
			}
			if (rule.count >= rule.requiredCount && !rule.fired) {
				rule.fired = true;
				requestedSection = rule.section;
			}
		}
	}

	private void runCommand(String command) {
		try {
			String os = System.getProperty("os.name").toLowerCase();
			ProcessBuilder builder = os.contains("win")
					? new ProcessBuilder("cmd.exe", "/c", command)
					: new ProcessBuilder("sh", "-c", command);
			Process process = builder.redirectErrorStream(true).start();
			BufferedReader output = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8));
			String result;
			while ((result = output.readLine()) != null) {
				System.out.println(result);
			}
			int exitCode = process.waitFor();
			if (exitCode != 0) {
				System.err.println("Command exited with code " + exitCode + ".");
			}
		} catch (Exception exception) {
			System.err.println("Could not run command: " + exception.getMessage());
		}
	}

	private Map<String, Integer> findSections(List<String> lines) {
		Map<String, Integer> sections = new HashMap<String, Integer>();
		for (int index = 0; index < lines.size(); index++) {
			String line = lines.get(index).trim();
			if (line.startsWith("/")) {
				String name = line.substring(1).split("[\\s*]", 2)[0];
				if (!name.isEmpty()) {
					sections.put(name.toLowerCase(), index);
				}
			}
		}
		return sections;
	}

	private void runSection(String name) {
		Integer start = sectionLines.get(name.toLowerCase());
		if (start == null) {
			System.err.println("No section named /" + name + ".");
			return;
		}
		for (int index = start.intValue() + 1; index < activeScriptLines.size(); index++) {
			String line = activeScriptLines.get(index).trim();
			if (line.startsWith("/")) {
				break;
			}
			execute(activeScriptLines.get(index));
			if (requestedSection != null) {
				String requested = requestedSection;
				requestedSection = null;
				runSection(requested);
			}
		}
	}

	private void assign(String line) {
		String body = line.substring(line.indexOf('=') + 1).trim();
		String[] parts = body.split(";", 2);
		if (parts.length != 2) {
			return;
		}
		String[] names = parts[0].split(",");
		String[] numbers = parts[1].replaceFirst("\\s+\\*.*$", "").split(",");
		for (int index = 0; index < Math.min(names.length, numbers.length); index++) {
			try {
				values.put(names[index].trim(), Double.parseDouble(numbers[index].trim().replaceAll("(?i)(mb|kb|gb)$", "")));
			} catch (NumberFormatException exception) {
				System.err.println("Invalid number: " + numbers[index].trim());
			}
		}
	}

	private boolean math(String line) {
		String expression = line.split("\\s+if\\s+", 2)[0].trim();
		java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("([-+]?\\w+)\\s*([+-])\\s*([-+]?\\w+)").matcher(expression);
		if (!matcher.matches()) {
			return false;
		}
		try {
			double left = number(matcher.group(1));
			double right = number(matcher.group(3));
			double result = matcher.group(2).equals("+") ? left + right : left - right;
			System.out.println(result == Math.rint(result) ? Long.toString((long) result) : Double.toString(result));
			Matcher condition = Pattern.compile("(?i)\\s+if\\s+([-+]?\\d+(?:\\.\\d+)?)\\s*,\\s*run\\s+next$").matcher(line);
			if (condition.find() && Math.abs(result - Double.parseDouble(condition.group(1))) > 0.000001) {
				skipNextLine = true;
			}
			return true;
		} catch (NumberFormatException exception) {
			return false;
		}
	}

	private void addObject(String line) {
		Matcher matcher = Pattern.compile("(?i)^add\\s+_(text|image)\\s+x,y;\\s*([^;]+);\\s*(?:([^;]+);\\s*)?\"([^\"]*)\"\\s+\"([^\"]+)\"(?:\\s+on\\s+_(\\d+)s)?$").matcher(line);
		if (!matcher.matches()) {
			System.err.println("Invalid add command: " + line);
			return;
		}
		try {
			double[] point = pair(matcher.group(2));
			double[] size = matcher.group(3) == null ? new double[] { 360, 42 } : pair(matcher.group(3));
			final ScreenObject object = new ScreenObject(matcher.group(1).toLowerCase(), matcher.group(5), matcher.group(4),
					(int) point[0], (int) point[1], Math.max(1, (int) size[0]), Math.max(1, (int) size[1]));
			if (matcher.group(6) == null) {
				objects.put(object.name, object);
				refreshScreen();
			} else {
				schedule(Integer.parseInt(matcher.group(6)), new Runnable() {
					public void run() {
						objects.put(object.name, object);
						refreshScreen();
					}
				});
			}
		} catch (IllegalArgumentException exception) {
			System.err.println("Invalid add coordinates: " + line);
		}
	}

	private void deleteObject(String line) {
		Matcher matcher = Pattern.compile("(?i)^delete\\s+\"([^\"]+)\"(?:\\s+on\\s+_(\\d+)s)?$").matcher(line);
		if (!matcher.matches()) {
			System.err.println("Invalid delete command: " + line);
			return;
		}
		final String name = matcher.group(1);
		if (matcher.group(2) == null) {
			objects.remove(name);
			refreshScreen();
		} else {
			schedule(Integer.parseInt(matcher.group(2)), new Runnable() {
				public void run() {
					objects.remove(name);
					refreshScreen();
				}
			});
		}
	}

	private void memoryCommand(String line) {
		Matcher matcher = Pattern.compile("(?i)^memory\\s+(add|load)\\s+\"([^\"]+)\"(?:\\s+at=line\\.\\d+)?$").matcher(line);
		if (!matcher.matches()) {
			System.err.println("Invalid memory command: " + line);
			return;
		}
		String action = matcher.group(1).toLowerCase();
		String name = matcher.group(2);
		if (action.equals("add")) {
			ScreenObject object = objects.get(name);
			if (object == null) {
				System.err.println("No screen object named \"" + name + "\" to remember.");
				return;
			}
			memory.put(name, object.copy());
			persistObject(object);
		} else {
			ScreenObject object = memory.get(name);
			if (object == null) {
				object = restoreObject(name);
			}
			if (object == null) {
				System.err.println("No remembered screen object named \"" + name + "\".");
				return;
			}
			objects.put(name, object.copy());
			refreshScreen();
		}
	}

	private void setCoordinates(String line) {
		Matcher matcher = Pattern.compile("(?i)^x,y;\\s*([^;]+);?$").matcher(line);
		if (matcher.matches()) {
			double[] point = pair(matcher.group(1));
			values.put("x", point[0]);
			values.put("y", point[1]);
		}
	}

	private void setStyleColor(String line) {
		Matcher matcher = Pattern.compile("(?i)^colour-([\\w-]+)\\s*=\\s*\\[\\s*(\\d+)\\s*,\\s*(\\d+)\\s*,\\s*(\\d+)\\s*\\]$")
				.matcher(line);
		if (!matcher.matches()) {
			System.err.println("Color format must be colour-name = [red, green, blue]: " + line);
			return;
		}
		String name = matcher.group(1).toLowerCase();
		if (!name.equals("back") && !name.equals("text") && !name.equals("text-back")
				&& !name.equals("accent") && !name.equals("border") && !name.equals("image-back")) {
			System.err.println("Unknown program color: colour-" + name);
			return;
		}
		try {
			int red = Integer.parseInt(matcher.group(2));
			int green = Integer.parseInt(matcher.group(3));
			int blue = Integer.parseInt(matcher.group(4));
			styleColors.put(name, new Color(red, green, blue));
			if (frame != null) {
				refreshScreen();
			}
		} catch (IllegalArgumentException exception) {
			System.err.println("Color channels must be between 0 and 255: " + line);
		}
	}

	private Color styleColor(String name, Color fallback) {
		Color color = styleColors.get(name);
		return color == null ? fallback : color;
	}

	private double[] pair(String text) {
		String[] coordinates = text.split(",");
		if (coordinates.length != 2) {
			throw new IllegalArgumentException("Expected two values");
		}
		return new double[] { number(coordinates[0].trim()), number(coordinates[1].trim()) };
	}

	private void showScreen() {
		if (GraphicsEnvironment.isHeadless()) {
			return;
		}
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				if (frame == null) {
					frame = new JFrame(programName);
					Image icon = applicationIcon();
					if (icon != null) {
						frame.setIconImage(icon);
					}
					frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
					frame.setSize(1280, 720);
					frame.setLocationRelativeTo(null);
					canvas = new JPanel(null);
					canvas.setBackground(styleColor("back", Color.WHITE));
					frame.setContentPane(canvas);
				} else {
					frame.setTitle(programName);
				}
				frame.setVisible(true);
				renderObjects();
			}
		});
	}

	private Image applicationIcon() {
		try (InputStream iconFile = runtime.class.getResourceAsStream("/oxm.png")) {
			return iconFile == null ? null : ImageIO.read(iconFile);
		} catch (IOException exception) {
			System.err.println("Could not load the Oxm application icon: " + exception.getMessage());
			return null;
		}
	}

	private void refreshScreen() {
		if (GraphicsEnvironment.isHeadless()) {
			return;
		}
		if (frame == null) {
			showScreen();
		} else {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					renderObjects();
				}
			});
		}
	}

	private void renderObjects() {
		if (canvas == null) {
			return;
		}
		canvas.removeAll();
		canvas.setBackground(styleColor("back", Color.WHITE));
		for (ScreenObject object : objects.values()) {
			JLabel label;
			if (object.type.equals("image")) {
				label = imageLabel(object);
			} else {
				label = new JLabel(object.value);
				label.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 20));
				label.setForeground(styleColor("text", Color.BLACK));
				Color textBackground = styleColors.get("text-back");
				if (textBackground != null) {
					label.setOpaque(true);
					label.setBackground(textBackground);
				}
				Border border = null;
				Color borderColor = styleColors.get("border");
				if (borderColor != null) {
					border = BorderFactory.createLineBorder(borderColor);
				}
				Color accentColor = styleColors.get("accent");
				if (accentColor != null) {
					Border accent = BorderFactory.createMatteBorder(0, 4, 0, 0, accentColor);
					border = border == null ? accent : BorderFactory.createCompoundBorder(border, accent);
				}
				if (border != null) {
					label.setBorder(border);
				}
			}
			label.setName(object.name);
			label.setBounds(object.x, object.y, object.width, object.height);
			canvas.add(label);
		}
		canvas.revalidate();
		canvas.repaint();
	}

	private JLabel imageLabel(ScreenObject object) {
		try {
			BufferedImage image = ImageIO.read(Paths.get(object.value).toFile());
			if (image != null) {
				Image scaled = image.getScaledInstance(object.width, object.height, Image.SCALE_SMOOTH);
				return new JLabel(new ImageIcon(scaled));
			}
		} catch (IOException exception) {
			System.err.println("Could not load image \"" + object.value + "\": " + exception.getMessage());
		}
		JLabel missing = new JLabel("Image unavailable: " + object.value);
		missing.setOpaque(true);
		missing.setBackground(styleColor("image-back", new Color(238, 238, 238)));
		return missing;
	}

	private void schedule(int seconds, final Runnable action) {
		if (GraphicsEnvironment.isHeadless()) {
			return;
		}
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				Timer timer = new Timer(seconds * 1000, event -> action.run());
				timer.setRepeats(false);
				timer.start();
			}
		});
	}

	private void persistObject(ScreenObject object) {
		String prefix = "object." + object.name + ".";
		persistedMemory.setProperty(prefix + "type", object.type);
		persistedMemory.setProperty(prefix + "value", object.value);
		persistedMemory.setProperty(prefix + "x", Integer.toString(object.x));
		persistedMemory.setProperty(prefix + "y", Integer.toString(object.y));
		persistedMemory.setProperty(prefix + "width", Integer.toString(object.width));
		persistedMemory.setProperty(prefix + "height", Integer.toString(object.height));
		try {
			Files.createDirectories(memoryPath.getParent());
			try (OutputStream output = Files.newOutputStream(memoryPath)) {
				persistedMemory.store(output, "Oxm screen memory");
			}
		} catch (IOException exception) {
			System.err.println("Could not save Oxm memory: " + exception.getMessage());
		}
	}

	private ScreenObject restoreObject(String name) {
		String prefix = "object." + name + ".";
		String type = persistedMemory.getProperty(prefix + "type");
		if (type == null) {
			return null;
		}
		try {
			ScreenObject object = new ScreenObject(type, name, persistedMemory.getProperty(prefix + "value", ""),
					Integer.parseInt(persistedMemory.getProperty(prefix + "x", "0")),
					Integer.parseInt(persistedMemory.getProperty(prefix + "y", "0")),
					Integer.parseInt(persistedMemory.getProperty(prefix + "width", "360")),
					Integer.parseInt(persistedMemory.getProperty(prefix + "height", "42")));
			memory.put(name, object);
			return object;
		} catch (NumberFormatException exception) {
			System.err.println("Invalid saved memory for \"" + name + "\".");
			return null;
		}
	}

	private void installLauncher() {
		try {
			Path jar = Paths.get(runtime.class.getProtectionDomain().getCodeSource().getLocation().toURI());
			if (!Files.isRegularFile(jar)) {
				return;
			}
			String local = System.getenv("LOCALAPPDATA");
			if (local == null || local.trim().isEmpty()) {
				return;
			}
			Path install = Paths.get(local, "Oxm");
			Path installedJar = install.resolve("oxm.jar");
			Path sourceLauncher = jar.resolveSibling("oxm.exe");
			Path installedLauncher = install.resolve("oxm.exe");
			Files.createDirectories(install);
			if (!jar.toAbsolutePath().normalize().equals(installedJar.toAbsolutePath().normalize())) {
				Files.copy(jar, installedJar, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
			}
			if (Files.isRegularFile(sourceLauncher)
					&& !sourceLauncher.toAbsolutePath().normalize().equals(installedLauncher.toAbsolutePath().normalize())) {
				Files.copy(sourceLauncher, installedLauncher, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
			}
			Path java = Paths.get(System.getProperty("java.home"), "bin", "java.exe");
			if (!Files.isRegularFile(java)) {
				java = Paths.get(System.getProperty("java.home")).getParent().resolve("bin").resolve("java.exe");
			}
			String launcher = "@echo off\r\n\"" + java + "\" -jar \"%~dp0oxm.jar\" %*\r\n";
			Files.write(install.resolve("oxm.cmd"), launcher.getBytes(StandardCharsets.UTF_8));
			if (System.getProperty("os.name").toLowerCase().contains("win")
					&& Files.isRegularFile(installedLauncher)
					&& !filesystem.registerOxmFileType(installedLauncher)) {
				System.err.println("Could not register .oxm files for double-click launch.");
			}
			String currentPath = registryPath();
			boolean alreadyPresent = false;
			for (String entry : currentPath.split(";")) {
				if (entry.trim().equalsIgnoreCase(install.toString())) {
					alreadyPresent = true;
				}
			}
			if (!alreadyPresent) {
				String updatedPath = currentPath.isEmpty() ? install.toString() : currentPath + ";" + install;
				Process process = new ProcessBuilder("reg.exe", "add", "HKCU\\Environment", "/v", "Path", "/t",
						"REG_EXPAND_SZ", "/d", updatedPath, "/f").redirectErrorStream(true).start();
			BufferedReader result = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8));
			while (result.readLine() != null) {
			}
				process.waitFor();
				System.out.println("Installed oxm command. Open a new terminal to use oxm from PATH.");
			}
		} catch (Exception exception) {
			System.err.println("Oxm PATH setup was not completed: " + exception.getMessage());
		}
	}

	private String registryPath() {
		try {
			Process process = new ProcessBuilder("reg.exe", "query", "HKCU\\Environment", "/v", "Path")
					.redirectErrorStream(true).start();
			BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8));
			String line;
			while ((line = reader.readLine()) != null) {
				Matcher matcher = Pattern.compile("^\\s*Path\\s+REG_\\w+\\s+(.*)$", Pattern.CASE_INSENSITIVE).matcher(line);
				if (matcher.matches()) {
					process.waitFor();
					return matcher.group(1).trim();
				}
			}
			process.waitFor();
		} catch (Exception exception) {
			System.err.println("Could not read the user PATH: " + exception.getMessage());
		}
		return "";
	}

	private Set<Integer> skippedLines(List<String> lines) {
		Set<Integer> skipped = new HashSet<Integer>();
		for (String line : lines) {
			if (!line.trim().toLowerCase().startsWith("back conditions;skip=")) {
				continue;
			}
			String conditions = line.substring(line.indexOf('=') + 1);
			Matcher singles = Pattern.compile("line\\.(\\d+)", Pattern.CASE_INSENSITIVE).matcher(conditions);
			while (singles.find()) {
				skipped.add(Integer.parseInt(singles.group(1)));
			}
			Matcher ranges = Pattern.compile("line,(\\d+)\\.(\\d+)", Pattern.CASE_INSENSITIVE).matcher(conditions);
			while (ranges.find()) {
				int start = Integer.parseInt(ranges.group(1));
				int end = Integer.parseInt(ranges.group(2));
				for (int number = Math.min(start, end); number <= Math.max(start, end); number++) {
					skipped.add(number);
				}
			}
		}
		return skipped;
	}

	private String stripDescription(String line) {
		for (int index = 0; index < line.length(); index++) {
			if (line.charAt(index) != '=') {
				continue;
			}
			int quote = index + 1;
			while (quote < line.length() && Character.isWhitespace(line.charAt(quote))) {
				quote++;
			}
			if (quote < line.length() && (line.charAt(quote) == '\'' || line.charAt(quote) == '`')) {
				return line.substring(0, index).trim();
			}
		}
		return line;
	}

	private static final class ScreenObject {
		final String type;
		final String name;
		final String value;
		final int x;
		final int y;
		final int width;
		final int height;

		ScreenObject(String type, String name, String value, int x, int y, int width, int height) {
			this.type = type;
			this.name = name;
			this.value = value;
			this.x = x;
			this.y = y;
			this.width = width;
			this.height = height;
		}

		ScreenObject copy() {
			return new ScreenObject(type, name, value, x, y, width, height);
		}
	}

	private static final class MessagePattern {
		final String prefix;
		final String suffix;

		MessagePattern(String prefix, String suffix) {
			this.prefix = prefix;
			this.suffix = suffix;
		}

		static MessagePattern parse(String source) {
			String[] markers = source.split(";", -1);
			if (markers.length != 2 || markers[0].trim().isEmpty() || markers[1].trim().isEmpty()) {
				return null;
			}
			return new MessagePattern(markers[0].trim(), markers[1].trim());
		}

		boolean matches(String message) {
			return message.startsWith(prefix) && message.endsWith(suffix);
		}
	}

	private static final class RepeatRule {
		final int requiredCount;
		final MessagePattern pattern;
		final String section;
		String lastMessage;
		int count;
		boolean fired;

		RepeatRule(int requiredCount, MessagePattern pattern, String section) {
			this.requiredCount = requiredCount;
			this.pattern = pattern;
			this.section = section;
		}
	}

	private double number(String text) {
		Double value = values.get(text);
		if (value != null) {
			return value.doubleValue();
		}
		return Double.parseDouble(text.trim().replaceFirst("(?i)(mb|kb|gb)$", ""));
	}
}
