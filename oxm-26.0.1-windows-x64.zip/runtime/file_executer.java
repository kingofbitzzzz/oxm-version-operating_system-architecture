package runtime;

public class file_executer {
	public static void main(String[] args) throws Exception {
		runtime.main(args);
	}
}
