@echo off
setlocal
set "ROOT=%~dp0.."
pushd "%ROOT%"
if not exist ".build" mkdir ".build"
windres filesystem\oxm.rc -O coff -o .build\oxm_icon.o
if errorlevel 1 (
	popd
	exit /b 1
)
gcc -municode -mconsole filesystem\oxm_launcher.c .build\oxm_icon.o -o oxm.exe -luser32
set "RESULT=%ERRORLEVEL%"
popd
exit /b %RESULT%
