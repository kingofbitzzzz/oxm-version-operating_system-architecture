@echo off
setlocal
set "ROOT=%~dp0.."
if not exist "%ROOT%\oxm.exe" (
	 echo oxm.exe is missing. Run terminal\build_launcher.bat first.
	 exit /b 1
)
"%ROOT%\oxm.exe" %*
exit /b %ERRORLEVEL%
