@echo off
setlocal
set "ROOT=%~dp0.."
pushd "%ROOT%"
if not exist ".build" mkdir ".build"
javac --release 8 -encoding UTF-8 -d .build filesystem\filesystem.java runtime\runtime.java runtime\file_executer.java syntax\syntax.java
if errorlevel 1 (
	popd
	exit /b 1
)
copy /y filesystem\oxm.png .build\oxm.png >nul
if errorlevel 1 (
	popd
	exit /b 1
)
jar cfe oxm.jar runtime.runtime -C .build .
if errorlevel 1 (
	popd
	exit /b 1
)
call terminal\build_launcher.bat
set "RESULT=%ERRORLEVEL%"
popd
exit /b %RESULT%