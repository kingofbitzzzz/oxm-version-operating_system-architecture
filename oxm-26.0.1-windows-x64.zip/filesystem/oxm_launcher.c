#include <windows.h>
#include <wchar.h>

static BOOL append_character(wchar_t *buffer, size_t capacity, size_t *length, wchar_t value) {
	if (*length + 1 >= capacity) {
		return FALSE;
	}
	buffer[(*length)++] = value;
	buffer[*length] = L'\0';
	return TRUE;
}

static BOOL append_text(wchar_t *buffer, size_t capacity, size_t *length, const wchar_t *text) {
	while (*text != L'\0') {
		if (!append_character(buffer, capacity, length, *text++)) {
			return FALSE;
		}
	}
	return TRUE;
}

static BOOL append_quoted_argument(wchar_t *buffer, size_t capacity, size_t *length, const wchar_t *argument) {
	if (!append_character(buffer, capacity, length, L'"')) {
		return FALSE;
	}
	while (TRUE) {
		size_t backslashes = 0;
		while (*argument == L'\\') {
			backslashes++;
			argument++;
		}
		if (*argument == L'\0') {
			for (size_t index = 0; index < backslashes; index++) {
				if (!append_character(buffer, capacity, length, L'\\')
						|| !append_character(buffer, capacity, length, L'\\')) {
					return FALSE;
				}
			}
			break;
		}
		if (*argument == L'"') {
			for (size_t index = 0; index < backslashes; index++) {
				if (!append_character(buffer, capacity, length, L'\\')
						|| !append_character(buffer, capacity, length, L'\\')) {
					return FALSE;
				}
			}
			if (!append_character(buffer, capacity, length, L'\\')
					|| !append_character(buffer, capacity, length, L'"')) {
				return FALSE;
			}
			argument++;
			continue;
		}
		for (size_t index = 0; index < backslashes; index++) {
			if (!append_character(buffer, capacity, length, L'\\')) {
				return FALSE;
			}
		}
		if (!append_character(buffer, capacity, length, *argument++)) {
			return FALSE;
		}
	}
	return append_character(buffer, capacity, length, L'"');
}

static BOOL find_java(wchar_t *java_path, DWORD capacity) {
	DWORD found = SearchPathW(NULL, L"java.exe", NULL, capacity, java_path, NULL);
	if (found > 0 && found < capacity) {
		return TRUE;
	}
	wchar_t java_home[MAX_PATH];
	DWORD home_length = GetEnvironmentVariableW(L"JAVA_HOME", java_home, MAX_PATH);
	if (home_length == 0 || home_length >= MAX_PATH) {
		return FALSE;
	}
	if (wcscat_s(java_home, MAX_PATH, L"\\bin\\java.exe") != 0) {
		return FALSE;
	}
	DWORD attributes = GetFileAttributesW(java_home);
	if (attributes == INVALID_FILE_ATTRIBUTES || (attributes & FILE_ATTRIBUTE_DIRECTORY) != 0) {
		return FALSE;
	}
	return wcscpy_s(java_path, capacity, java_home) == 0;
}

int wmain(int argument_count, wchar_t **arguments) {
	wchar_t executable_path[32768];
	DWORD path_length = GetModuleFileNameW(NULL, executable_path, 32768);
	if (path_length == 0 || path_length >= 32768) {
		fwprintf(stderr, L"Could not locate the Oxm launcher.\n");
		return 1;
	}
	wchar_t *separator = wcsrchr(executable_path, L'\\');
	if (separator == NULL) {
		fwprintf(stderr, L"Could not locate the Oxm installation folder.\n");
		return 1;
	}
	separator[1] = L'\0';

	wchar_t jar_path[32768];
	if (wcscpy_s(jar_path, 32768, executable_path) != 0
			|| wcscat_s(jar_path, 32768, L"oxm.jar") != 0) {
		fwprintf(stderr, L"Oxm installation path is too long.\n");
		return 1;
	}
	DWORD jar_attributes = GetFileAttributesW(jar_path);
	if (jar_attributes == INVALID_FILE_ATTRIBUTES || (jar_attributes & FILE_ATTRIBUTE_DIRECTORY) != 0) {
		fwprintf(stderr, L"Could not find oxm.jar beside the launcher:\n%ls\n", jar_path);
		return 1;
	}

	wchar_t java_path[MAX_PATH];
	if (!find_java(java_path, MAX_PATH)) {
		fwprintf(stderr, L"Java was not found. Install Java and try again.\n");
		return 1;
	}

	wchar_t command_line[32767] = L"";
	size_t command_length = 0;
	if (!append_quoted_argument(command_line, 32767, &command_length, java_path)
			|| !append_text(command_line, 32767, &command_length, L" -jar ")
			|| !append_quoted_argument(command_line, 32767, &command_length, jar_path)) {
		fwprintf(stderr, L"Oxm command line is too long.\n");
		return 1;
	}
	for (int index = 1; index < argument_count; index++) {
		if (!append_character(command_line, 32767, &command_length, L' ')
				|| !append_quoted_argument(command_line, 32767, &command_length, arguments[index])) {
			fwprintf(stderr, L"Oxm command line is too long.\n");
			return 1;
		}
	}

	STARTUPINFOW startup;
	PROCESS_INFORMATION process;
	ZeroMemory(&startup, sizeof(startup));
	ZeroMemory(&process, sizeof(process));
	startup.cb = sizeof(startup);
	if (!CreateProcessW(java_path, command_line, NULL, NULL, TRUE, 0, NULL, executable_path, &startup, &process)) {
		fwprintf(stderr, L"Could not start Java (error %lu).\n", GetLastError());
		return 1;
	}
	WaitForSingleObject(process.hProcess, INFINITE);
	DWORD exit_code = 1;
	GetExitCodeProcess(process.hProcess, &exit_code);
	CloseHandle(process.hThread);
	CloseHandle(process.hProcess);
	return (int) exit_code;
}
