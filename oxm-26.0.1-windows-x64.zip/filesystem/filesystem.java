package filesystem;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class filesystem {
	private filesystem() {
	}

	public static boolean isOxmFile(Path file) {
		return file != null && file.getFileName() != null
				&& file.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".oxm");
	}

	public static boolean registerOxmFileType(Path launcher) throws IOException, InterruptedException {
		if (!System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win")) {
			return false;
		}
		String absoluteLauncher = launcher.toAbsolutePath().normalize().toString();
		String openCommand = "cmd.exe /k \"\"" + absoluteLauncher + "\" \"%1\"\"";
		String registryFile = "Windows Registry Editor Version 5.00\r\n\r\n"
				+ "[HKEY_CURRENT_USER\\Software\\Classes\\.oxm]\r\n"
				+ "@=\"Oxm.Script\"\r\n\r\n"
				+ "[HKEY_CURRENT_USER\\Software\\Classes\\Oxm.Script]\r\n"
				+ "@=\"O Programming\"\r\n"
				+ "\"FriendlyTypeName\"=\"O Programming\"\r\n\r\n"
				+ "[HKEY_CURRENT_USER\\Software\\Classes\\Oxm.Script\\DefaultIcon]\r\n"
				+ "@=\"" + escapeRegistryString(absoluteLauncher + ",0") + "\"\r\n\r\n"
				+ "[HKEY_CURRENT_USER\\Software\\Classes\\Oxm.Script\\shell\\open\\command]\r\n"
				+ "@=\"" + escapeRegistryString(openCommand) + "\"\r\n";
		Path registrationFile = Files.createTempFile("oxm-association-", ".reg");
		try {
			Files.write(registrationFile, ("\uFEFF" + registryFile).getBytes(StandardCharsets.UTF_16LE));
			Process process = new ProcessBuilder("reg.exe", "import", registrationFile.toString())
					.redirectErrorStream(true).start();
			List<String> outputLines = new ArrayList<String>();
			try (BufferedReader output = new BufferedReader(
					new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
			String outputLine;
			while ((outputLine = output.readLine()) != null) {
				outputLines.add(outputLine);
				}
			}
			int exitCode = process.waitFor();
			if (exitCode != 0) {
				System.err.println("Registry import failed: " + String.join(" ", outputLines));
			}
			return exitCode == 0;
		} finally {
			Files.deleteIfExists(registrationFile);
		}
	}

	public static Process openOxmFileInTerminal(Path file, Path launcher) throws IOException {
		if (!isOxmFile(file)) {
			throw new IllegalArgumentException("File must have the .oxm extension: " + file);
		}
		String command = "\"\"" + launcher.toAbsolutePath().normalize() + "\" \""
				+ file.toAbsolutePath().normalize() + "\"\"";
		return new ProcessBuilder("cmd.exe", "/k", command).start();
	}

	private static String escapeRegistryString(String value) {
		return value.replace("\\", "\\\\").replace("\"", "\\\"");
	}
}
