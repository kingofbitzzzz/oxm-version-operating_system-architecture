package syntax;

public class syntax {
	public static String help() {
		return "Oxm statements: root:file.oxm; int = names;values; x + y / x - y; /section; "
				+ "back conditions;skip=line.2,line,7.10; group size,memory \"name\"; edit \"name\"; "
				+ "add _text|_image x,y;location;[size;] \"text or path\" \"name\" [on _Ns]; "
				+ "colour-back/text/text-back/accent/border/image-back = [red, green, blue]; "
				+ "delete \"name\" [on _Ns]; memory add/load \"name\"; fetch;...; out:file.oxm; screen_load. "
				+ "teletypewriter.mock on/off; teletypewriter.type \"message\"; teletypewriter.cmd \"command\"; "
				+ "teletypewriter.block \"&start;&end\"; teletypewriter.ifNUMBERti \"&start;&end\" run section. "
				+ "Shell: run file.oxm, help, exit.";
	}
}
